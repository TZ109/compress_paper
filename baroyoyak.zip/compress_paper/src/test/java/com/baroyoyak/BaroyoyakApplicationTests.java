package com.baroyoyak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaroyoyakApplicationTests {

	@Test
	void contextLoads() {
	}

}
