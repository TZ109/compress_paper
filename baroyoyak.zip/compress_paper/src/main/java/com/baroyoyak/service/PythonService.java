package com.baroyoyak.service;

public class PythonService {

	public String executePython(String text)
	{
		String result = text;
		return result;
	}
}
